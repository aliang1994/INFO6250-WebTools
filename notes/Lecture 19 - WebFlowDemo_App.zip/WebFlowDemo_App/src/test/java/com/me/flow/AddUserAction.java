package com.me.flow;

import org.springframework.webflow.execution.Action;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

public class AddUserAction implements Action
{

	public Event execute(RequestContext arg0) throws Exception {
		// TODO Auto-generated method stub
		boolean userexists = false;
		
		if (userexists)
			return new Event(this, "showorder");
		else
			return new Event(this, "adduser");
	}

}
;