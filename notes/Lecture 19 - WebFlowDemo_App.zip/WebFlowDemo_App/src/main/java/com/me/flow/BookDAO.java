package com.me.flow;

import java.util.List;
import java.util.ArrayList;

public class BookDAO
{
	public List<String> getBooks()
	{
		List<String> books = new ArrayList<String>();
		books.add("Spring MVC Programming");
		books.add("Oracle 10g");
		books.add("Microsoft SQL Server");
		books.add("Java EE Programming");
		return books;
	}
}