package com.me.flow;

import org.springframework.webflow.execution.Action;
import org.springframework.webflow.execution.Event;
import org.springframework.webflow.execution.RequestContext;

public class LookupUser implements Action
{

	public Event execute(RequestContext arg0) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
