package com.me.service;

public class UserService {
    public String getData(int param) {
        return "Server Data: " + param;
    }
}
